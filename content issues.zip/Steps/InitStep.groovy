initStep = stepFactory.createStep("InitStep")

initStep.run = {
  println "initStep.run"
  g.random(1)
}
initStep.done = {
  println "initStep.done"
}