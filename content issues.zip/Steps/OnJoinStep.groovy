onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId->
  println "onJoinStep.run"
  def player = g.getVertex(playerId)
  player.text = c.get("content")
}
onJoinStep.done = {
  println "onJoinStep.done"
}