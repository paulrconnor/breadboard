// Global variables

curStep = "start"

groupCounter = 0
matrixCounter = 0

p1 = null
p2 = null
p3 = null
p4 = null
p5 = null
p6 = null

import java.util.Random  
Random rand = new Random() 

justification = rand.nextInt(3)

colors = rand.nextInt(2)

aiBehavior = { player ->
  if (player.getProperty("choices")) {
    def choices = player.getProperty("choices")
    def choice = choices[r.nextInt(choices.size())]
    def params = null
    if (curStep == "proposal" && player.proposer) {
      params = [allocation: (r.nextInt(sum)).toString()]
    }
    a.choose(choice.uid, params)
  }
}

matrixA1 = [[1,19],[3,18],[5,17],[7,16],[9,15],[11,14],[13,13],[15,12],[17,11],[19,10],[21,9],[23,8],[25,7]]

matrixA2 = [[19,1],[18,3],[17,5],[16,7],[15,9],[14,11],[13,13],[12,15],[11,17],[10,19],[9,21],[8,23],[7,25]]

matrixB1 = [[7,1],[8,3],[9,5],[10,7],[11,9],[12,11],[13,13],[14,15],[15,17],[16,19],[17,21],[18,23],[19,25]]

matrixB2 = [[1,7],[3,8],[5,9],[7,10],[9,11],[11,12],[13,13],[15,14],[17,15],[19,16],[21,17],[23,18],[25,19]]

matrixC1 = [[26,2],[25,3],[24,4],[23,5],[22,6],[21,7],[20,8],[19,9],[18,10],[17,11],[16,12],[15,13],[14,14]]

matrixC2 = [[2,26],[3,25],[4,24],[5,23],[6,22],[7,21],[8,20],[9,19],[10,18],[11,17],[12,16],[13,15],[14,14]]

matrices = [matrixA1, matrixA2, matrixB1, matrixB2, matrixC1, matrixC2]

Collections.shuffle(matrices)

initStep = stepFactory.createStep()

initStep.run = {
  
  println "initStep.run"
  
  curRound = 1
  
  curStep = "init"
  
  g.V.filter{ it.active }.each { v -> 
    
    if (v.score == 1) {
      v.p1 = true
      p1 = v
    }
    
    if (v.score == 2) {
      v.p2 = true
      p2 = v
    }
    
    if (v.score == 3) {
      v.p3 = true
      p3 = v
    }
    
    if (v.score == 4) {
      v.p4 = true
      p4 = v
    }
    
    if (v.score == 5) {
      v.p5 = true
      p5 = v
    }
    
    if (v.score == 6) {
      v.p6 = true
      p6 = v
    }
    
  }
  
  g.V.filter{ it.active }.each { player ->
    
    player.text = c.get("PleaseWait") + "<p><strong>Click 'Begin' to join the game.</strong></p>"
    
    a.add(player, [name: "Begin", result: {
      player.text = c.get("PleaseWait") + "<p><strong>Thank you, the game will begin in a moment.</strong></p>"
    }])
    
  }
  
}

initStep.done = {
  
  println "initStep.done"
  pairingStep.start()
  
}
