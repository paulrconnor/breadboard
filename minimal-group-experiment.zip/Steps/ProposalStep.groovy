proposalStep = stepFactory.createStep()

proposalStep.run = {
  
  println "proposalStep.run: ${curRound}"
  curStep = "proposal"
  
  g.V.filter{ it.active }.each { v ->
    
    v.currentneighbors = []
    
    v.neighbors.each { n ->
      v.currentneighbors += [[n.score, n.col]]
    }

    if (v.currentneighbors[0][1] == "r" && v.currentneighbors[1][1] == "b"){
      v.text = c.get("AllocationRB", 
                     v.currentneighbors[0][0], 
                     v.currentneighbors[1][0],
                     matrices[matrixCounter][0][0], matrices[matrixCounter][0][1],
                     matrices[matrixCounter][1][0], matrices[matrixCounter][1][1],
                     matrices[matrixCounter][2][0], matrices[matrixCounter][2][1],
                     matrices[matrixCounter][3][0], matrices[matrixCounter][3][1],
                     matrices[matrixCounter][4][0], matrices[matrixCounter][4][1],
                     matrices[matrixCounter][5][0], matrices[matrixCounter][5][1],
                     matrices[matrixCounter][6][0], matrices[matrixCounter][6][1],
                     matrices[matrixCounter][7][0], matrices[matrixCounter][7][1],
                     matrices[matrixCounter][8][0], matrices[matrixCounter][8][1],
                     matrices[matrixCounter][9][0], matrices[matrixCounter][9][1],
                     matrices[matrixCounter][10][0], matrices[matrixCounter][10][1],
                     matrices[matrixCounter][11][0], matrices[matrixCounter][11][1],
                     matrices[matrixCounter][12][0], matrices[matrixCounter][12][1]
                    )
    }
    
    if (v.currentneighbors[0][1] == "b" && v.currentneighbors[1][1] == "r"){
      v.text = c.get("AllocationBR", 
                     v.currentneighbors[0][0], 
                     v.currentneighbors[1][0],
                     matrices[matrixCounter][0][0], matrices[matrixCounter][0][1],
                     matrices[matrixCounter][1][0], matrices[matrixCounter][1][1],
                     matrices[matrixCounter][2][0], matrices[matrixCounter][2][1],
                     matrices[matrixCounter][3][0], matrices[matrixCounter][3][1],
                     matrices[matrixCounter][4][0], matrices[matrixCounter][4][1],
                     matrices[matrixCounter][5][0], matrices[matrixCounter][5][1],
                     matrices[matrixCounter][6][0], matrices[matrixCounter][6][1],
                     matrices[matrixCounter][7][0], matrices[matrixCounter][7][1],
                     matrices[matrixCounter][8][0], matrices[matrixCounter][8][1],
                     matrices[matrixCounter][9][0], matrices[matrixCounter][9][1],
                     matrices[matrixCounter][10][0], matrices[matrixCounter][10][1],
                     matrices[matrixCounter][11][0], matrices[matrixCounter][11][1],
                     matrices[matrixCounter][12][0], matrices[matrixCounter][12][1]                     
                    )
    }
    
    if (v.currentneighbors[0][1] == "r" && v.currentneighbors[1][1] == "r"){
      v.text = c.get("AllocationRR", 
                     v.currentneighbors[0][0], 
                     v.currentneighbors[1][0],
                     matrices[matrixCounter][0][0], matrices[matrixCounter][0][1],
                     matrices[matrixCounter][1][0], matrices[matrixCounter][1][1],
                     matrices[matrixCounter][2][0], matrices[matrixCounter][2][1],
                     matrices[matrixCounter][3][0], matrices[matrixCounter][3][1],
                     matrices[matrixCounter][4][0], matrices[matrixCounter][4][1],
                     matrices[matrixCounter][5][0], matrices[matrixCounter][5][1],
                     matrices[matrixCounter][6][0], matrices[matrixCounter][6][1],
                     matrices[matrixCounter][7][0], matrices[matrixCounter][7][1],
                     matrices[matrixCounter][8][0], matrices[matrixCounter][8][1],
                     matrices[matrixCounter][9][0], matrices[matrixCounter][9][1],
                     matrices[matrixCounter][10][0], matrices[matrixCounter][10][1],
                     matrices[matrixCounter][11][0], matrices[matrixCounter][11][1],
                     matrices[matrixCounter][12][0], matrices[matrixCounter][12][1]                     
                    )
    }
    
    if (v.currentneighbors[0][1] == "b" && v.currentneighbors[1][1] == "b"){
      v.text = c.get("AllocationBB", 
                     v.currentneighbors[0][0], 
                     v.currentneighbors[1][0],
                     matrices[matrixCounter][0][0], matrices[matrixCounter][0][1],
                     matrices[matrixCounter][1][0], matrices[matrixCounter][1][1],
                     matrices[matrixCounter][2][0], matrices[matrixCounter][2][1],
                     matrices[matrixCounter][3][0], matrices[matrixCounter][3][1],
                     matrices[matrixCounter][4][0], matrices[matrixCounter][4][1],
                     matrices[matrixCounter][5][0], matrices[matrixCounter][5][1],
                     matrices[matrixCounter][6][0], matrices[matrixCounter][6][1],
                     matrices[matrixCounter][7][0], matrices[matrixCounter][7][1],
                     matrices[matrixCounter][8][0], matrices[matrixCounter][8][1],
                     matrices[matrixCounter][9][0], matrices[matrixCounter][9][1],
                     matrices[matrixCounter][10][0], matrices[matrixCounter][10][1],
                     matrices[matrixCounter][11][0], matrices[matrixCounter][11][1],
                     matrices[matrixCounter][12][0], matrices[matrixCounter][12][1]                     
                    )
    }
    
    a.add(v,
            [name: "A",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][0][0]
                 } else {
                   n.truescore += matrices[matrixCounter][0][1]
                 }}}],
          
            [name: "B",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][1][0]
                 } else {
                   n.truescore += matrices[matrixCounter][1][1]
                 }}}],

            [name: "C",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][2][0]
                 } else {
                   n.truescore += matrices[matrixCounter][2][1]
                 }}}],
         
            [name: "D",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][3][0]
                 } else {
                   n.truescore += matrices[matrixCounter][3][1]
                 }}}],         
         
            [name: "E",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][4][0]
                 } else {
                   n.truescore += matrices[matrixCounter][4][1]
                 }}}],         
         
            [name: "F",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][5][0]
                 } else {
                   n.truescore += matrices[matrixCounter][5][1]
                 }}}],         
         
            [name: "G",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][6][0]
                 } else {
                   n.truescore += matrices[matrixCounter][6][1]
                 }}}],         
         
            [name: "H",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][7][0]
                 } else {
                   n.truescore += matrices[matrixCounter][7][1]
                 }}}],         
         
            [name: "I",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][8][0]
                 } else {
                   n.truescore += matrices[matrixCounter][8][1]
                 }}}],         
         
            [name: "J",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][9][0]
                 } else {
                   n.truescore += matrices[matrixCounter][9][1]
                 }}}],         
         
            [name: "K",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][10][0]
                 } else {
                   n.truescore += matrices[matrixCounter][10][1]
                 }}}],         
         
            [name: "L",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][11][0]
                 } else {
                   n.truescore += matrices[matrixCounter][11][1]
                 }}}],         
         
            [name: "M",
             result:{
               v.text = c.get("WaitAllocation")
               v.neighbors.each{ n ->
                 if(n.score == v.currentneighbors[0][0]){
                   n.truescore += matrices[matrixCounter][12][0]
                 } else {
                   n.truescore += matrices[matrixCounter][12][1]
                 }}}]      
         )
  }
}

proposalStep.done = {
  println "proposalStep.done: ${curRound}"
  
  if (curRound < 60) {
    
    curRound++
      
    groupCounter++
      
    if (groupCounter == 10) {
      groupCounter = 0
      matrixCounter++
    }
    
    g.removeEdges()
    
    pairingStep.start()

  } else {
    
    println "Done"
    
  }
}
